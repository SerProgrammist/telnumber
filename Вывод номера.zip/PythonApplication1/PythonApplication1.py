import re

Reg = r'([9]\d{9}-\w+)'

with open("number.txt", "r", encoding='utf-8') as f:
    number_txt = f.readlines()

whole_txt = "".join(number_txt)

matches = re.findall(Reg, whole_txt, flags=re.MULTILINE)

print (matches)